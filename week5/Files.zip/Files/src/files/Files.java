/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package files;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author alexandra.vaschillo
 */
public class Files {

     public static void main(String[] args) //throws IOException
   {
      String filename;      // File name
     
      int howMany;       // Number of friends

      // Create a Scanner object for keyboard input.
      Scanner keyboard = new Scanner(System.in);
      
      // Get the number of friends.
      System.out.print("How many numbers to generate? ");
      howMany = keyboard.nextInt();

      // Consume the remaining newline character.
      keyboard.nextLine();
      
      // Get the filename.
     // System.out.print("Enter the filename: ");
      filename  = "numbers.txt"; //= keyboard.nextLine();
      Random rand = new Random();
    try{
      writeRandom(filename, howMany);
   }
    catch(Exception e)
    {
        System.out.println("IOException! :" +e.getMessage());
    }
      System.out.println("Data written to the file.");    
      
      System.out.print("Enter the name of a file to ead numbers from: ");
     // filename = keyboard.nextLine();

   /*   // Open the file.
      File file = new File(filename);
      int evens =0;
      int fives = 0; 
      try{
        Scanner inputFile = new Scanner(file);
        while(inputFile.hasNext())
        {
            String str = inputFile.nextLine();
            int num = Integer.parseInt(str);
            if(num%2==0) evens++;
            if(num==5) fives++;
        }
        inputFile.close();
        System.out.println("The number of even integers is : "+evens);
        System.out.println("The number of fives : "+fives);
      }
      catch(IOException e)
        {
            System.out.println("Input IO Exception!! " +e.getMessage() );
        }
*/
   }
 /**
  * Method generates random numbers in the range [1,55]
  * Writes them into the file specified by parameter
  * one number per line
  * @param fileName
  * @param howMany 
  */
  public static void writeRandom(String fileName, int howMany) throws Exception 
  {
      Random rand = new Random();
   
        // Open the file.
        PrintWriter outputFile = new PrintWriter(fileName);

        // Get data and write it to the file.
        for (int i = 0; i < howMany; i++)
        {
           // generate a number [1, 55]
           int r = rand.nextInt(55)+1;
           // Write the name to the file.
           outputFile.println(r);
        }

        // Close the file.
        outputFile.close();
   
   
  }
    
}
