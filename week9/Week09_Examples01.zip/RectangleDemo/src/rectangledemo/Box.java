/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangledemo;

/**
 *
 * @author alexandra.vaschillo
 */
public class Box {
    private Rectangle base; // aggregation
    private double height;
    
    public Box()
    {
        base = new Rectangle();
        height = 1;
    }
    public Box(double len, double wid, double h)
    {
        base = new Rectangle(len, wid);
        if(h<=0)throw new IllegalArgumentException("Height cannot be negative; "+h);
        else height = h;
    }
    
    public Box(Rectangle b, double h)
    {
        //base = b; // shallow copy
        base = new Rectangle(b);// deep copy
        
        if(h<=0)throw new IllegalArgumentException("Height cannot be negative; "+h);
        else height = h;
    }
    
    public void setBase(Rectangle b)
    {
       base = new Rectangle(b); 
    }
    // Privacy leak!!
 /*   public Rectangle getBase()
    {
        return base; 
    }
 */  
    public Rectangle getBase()
    { // return a copy of the private field
        return new Rectangle(base); 
    }
      
    @Override public String toString()
    {
        return "Width = "+base.getWidth()+"; Length = "+base.getLength()+"; Height = "+height; 
    }
}
