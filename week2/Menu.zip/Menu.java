/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

import java.util.Scanner;

/**
 *
 * @author alexandra.vaschillo
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
         Scanner keyboard = new Scanner(System.in);
         boolean go = true;
         while(go)
         {
            System.out.println("1. Calculate the Area of a Circle \n"
                  + "2. Calculate the Area of a Rectangle \n"
                  + "3. Calculate the Area of a Triangle \n"
                  + "4. Quit"); 
            System.out.print("=> ");
            int choice = keyboard.nextInt();
            switch(choice)
            {
                case 1:
                    System.out.println("You chose to Calculate the Area of a Circle");
                   System.out.print("Please enter radius value =>");
                   double r = keyboard.nextDouble();
                    while(r<=0)
                    {
                       System.out.println("radius must be a positive number! Please try again");
                       System.out.print("Please eneter radius value =>");
                      r = keyboard.nextDouble();
                    }
                    break;
                case 2:
                    System.out.println("You chose to Calculate the Area of a Rectangle");
                    break;
                case 3:
                    System.out.println("You chose to Calculate the Area of a Triangle");
                    break;
                 case 4:
                    go=false;
                     System.out.println("You chose to Quit");
                     break;
                default:
                   System.out.println(choice + " is not an option.\n "
                           + "Please reload the program and try again");  
               }
         }
    }
    
}
