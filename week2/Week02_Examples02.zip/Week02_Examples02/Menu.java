/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

import java.util.Scanner;

/**
 *
 * @author alexandra.vaschillo
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int choice = 0;
        do {
        System.out.println("Geometry Calculator:\n1. Calculate the Area of a Circle\n2. Calculate the Area of a Rectangle\n3. Quit\nEnter your choice (1 – 3):");
        Scanner keyboard = new Scanner(System.in);
        choice = keyboard.nextInt();
        if(choice<=3&&choice>=1)
        {
            // do the switch
            switch(choice)
            {
                case 1:
                    System.out.println("calculating circle area");
                    // prompt
                    // input radius as double
                    //check if it is not neative
                    // calculate and output area
                    // if negative - output error message
                    break;
                case 2: 
                    System.out.println("calculating Area of a Rectangle");
                    break;
                case 3:
                    // does nothing!!
                    System.out.println("Quitting");
            }
        }
        else
        {
            System.out.println("No such choice in the menu");
        }
        } while(choice!=3);
    }
    
}
