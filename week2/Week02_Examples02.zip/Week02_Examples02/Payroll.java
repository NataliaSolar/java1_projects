/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll;

import java.util.Scanner;
import java.util.Random;
//import java.lang.Math;

/**
 *
 * @author alexandra.vaschillo
 * Alexandra Vaschillo
 */
public class Payroll
{
   public static void main(String[] args)
   {
      String name;         // To hold a name
      int hours = 5;           // Hours worked
      double payRate;      // Hourly pay rate
      double grossPay;     // Gross pay
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      // Get the user's name.
    /*  System.out.print("What is your name? ");
      name = keyboard.nextLine();
      
      // Get the number of hours worked this week.
      System.out.print("How many hours did you work this week? ");
      hours = keyboard.nextInt();
      
      // Get the user's hourly pay rate.
      System.out.print("What is your hourly pay rate? ");
      payRate = keyboard.nextDouble();
      
      // Calculate the gross pay.
      grossPay = hours * payRate;
     
      System.out.print("Please enter the first string: ");
      String s1 = keyboard.nextLine();
      System.out.print("Please enter the second string: ");
      String s2 = keyboard.nextLine();
     System.out.println("\nEcho print; comparing \""+s1+
                        "\"  \""+s2+"\"");
      
      if(s1.equals(s2))
      {
          System.out.println("EQUAL!!");
      }
      else System.out.println("DIFFERENT!!");
       */   
    //hours=5;
     // input validation
     Random randomNumbers = new Random(); // set up an object to generate numbers
     
     boolean go=true;
     int count = 0;
        while(go)
        {
            System.out.println("How many iterations do we want?");
            count = keyboard.nextInt();
            if(count<=0) System.out.println("Please enter a positive value");
            else go=false;
        }
        // illustration of running total
        // [0, N] r = randomNumbers.nextInt(N-1);
        // [N, M] r = randomNumbers.nextInt((M - N) + 1) + N;
        int total =0;
       for(int i = 1; i<=count; i++) 
       {
           int r = randomNumbers.nextInt(3);
           System.out.println(r);
           total+=r; // total= total+i;
       }
       //System.out.printf("The total of all integers in the range[0, %d] is %d\n", count, total);
       System.out.printf("%-10s  %-5s \n", "Hex Number", "Number");
       for(int i = 1; i<=count; i++) 
       {
          if(i>17) break;
          if(i%5==0)continue;
          System.out.printf( "%-10x  %-5d \n", i, i);
          
       }
       
        
     /* int a = 5;
      int b = 6;
      int c = a+ ++b;
      System.out.printf("a=%d; b=%d; c=%d\n", a, b, c);
     */ 
      //double a =0.45678E3;
      //double n = Math.pow(hours, 5);
      
      // Display the resulting information.
    //  System.out.println("Hello, " + name);
     // System.out.println("Your gross pay is $" + grossPay);
   }
}


