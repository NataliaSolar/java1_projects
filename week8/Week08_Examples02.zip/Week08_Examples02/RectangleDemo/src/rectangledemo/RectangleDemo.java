/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangledemo;
import java.util.*;
/**
 *
 * @author alexandra.vaschillo
 */
public class RectangleDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double n = Math.pow(4, 5);
       
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle();
        System.out.printf("Length: %.2f and Width: %.2f; Area is %.2f\n", r1.getLength(), r1.getWidth(), r1.getArea());
        //r1.length = 9;
        r1.setLength(9);
        r1.setWidth(45);
        System.out.printf("Length: %.2f and Width: %.2f; Area is %.2f; Count is %d\n", r1.getLength(), r1.getWidth(), r1.getArea(), Rectangle.getCount());
        
        Rectangle[] array = new Rectangle[10];
        for(int i=0; i<array.length; i++)
        {
           array[i] = new Rectangle(i+1, i+1); 
        }
        // using linear search to lok for a rectangle with specified area
        int area = 4;
        int index = -1;
        boolean go=true;
        for(int i=0; go&&i<array.length; i++)
        {
            if(array[i].getArea()==area) 
            {
                index=i;
                go=false;
            }
        }
    }
    
}
