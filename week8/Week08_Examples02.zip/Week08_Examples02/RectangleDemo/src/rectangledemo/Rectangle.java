/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangledemo;

/**
 *
 * @author alexandra.vaschillo
 */
public class Rectangle {
    
    private double length;
    private double width;
    private static int count;
    //private double area;
    /**
     * Non-argument constructor, sets length and width to 1
     */
    public Rectangle()
    {
        length = 1;
        width = 1;
        count++;
    }
  
    public Rectangle(double len, double wid)
    {
        if(len<0) throw new IllegalArgumentException("Length cannot be negative; "+len);
        else this.length = len; 
        
        if(wid<0) throw new IllegalArgumentException("Width cannot be negative; "+wid);
        else width = wid;
    }
            
    public static int getCount()
    {
       // double a = length+width;
        return count;
    }
    /**
     * Accessor for length field
     * @return length of the rectangle
     */
    public double getLength()
    {
        return length;
    }
    /**
     * Accessor method for width
     * @return width field value 
     */
    public double getWidth()
    {
        return width;
    }
   /**
    * Sets the length field of the object
    * @param length value to set the field
    * @throws IllegalArgumentException thrown when the parameter has negative value
    */
    public void setLength(double length)throws IllegalArgumentException
    {
        if(length<0) throw new IllegalArgumentException("Length cannot be negative; "+length);
        else this.length = length;
    }
    
    /**
     * Sets the width field of the class
     * @param wid width given
     * @throws IllegalArgumentException  thrown when the width is negative
     */
    public void setWidth(double wid)throws IllegalArgumentException
    {
        if(wid<0) throw new IllegalArgumentException("Width cannot be negative; "+wid);
        else width = wid;
    }
     
     public double getArea()
     {
         return length*width;
     }
}
